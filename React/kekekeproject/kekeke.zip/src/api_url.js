// api 기본 주소 

//const API_URL = `http://192.168.70.65:3333`; // 춘모 서버




//const API_URL = `http://localhost:3333`; // 본인 컴퓨터 서버


 const API_URL = `http://ec2-3-39-101-66.ap-northeast-2.compute.amazonaws.com:3333`; //용민 컴퓨터

//const API_URL = `http://192.168.100.69:3333`


export default API_URL;