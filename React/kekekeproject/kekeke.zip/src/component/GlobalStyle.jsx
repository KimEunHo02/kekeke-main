// GlobalStyle.js
import { createGlobalStyle } from 'styled-components';

const GlobalStyle = createGlobalStyle`
  body {
    background-color: #ffffe7; // 원하는 배경색으로 설정
  }
`;

export default GlobalStyle;
